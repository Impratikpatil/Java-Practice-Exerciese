package Unsorted_List;
import java.util.Arrays;

public class FourthSmallest {
    public static void main(String[] args) {
        int[] nums = {9,2,5,7,8,3,6,1,4};
        int fourthSmallest = findFourthSmallest(nums);
        
        System.out.println("Original List is: " + Arrays.toString(nums));
        System.out.println("Fourth Smallest Element is: " + fourthSmallest);
    }
    
    public static int findFourthSmallest(int[] nums) {
        if (nums.length < 4) {
            System.out.println("List has less than 4 elements");
            return -1;
        }
        
        Arrays.sort(nums);
        return nums[3]; // Index 3 corresponds to the fourth smallest element
    }
}

