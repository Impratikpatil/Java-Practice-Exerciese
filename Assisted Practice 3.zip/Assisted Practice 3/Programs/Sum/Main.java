package Sum;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        try (Scanner scanner = new Scanner(System.in)) {
			System.out.print("Enter the value of n: ");
			int n = scanner.nextInt();

			// Create an array of size n
			int[] array = new int[n];

			// Read array elements
			System.out.println("Enter the array elements:");
			for (int i = 0; i < n; i++) {
			    array[i] = scanner.nextInt();
			}

			System.out.print("Enter the value of L: ");
			int L = scanner.nextInt();

			System.out.print("Enter the value of R: ");
			int R = scanner.nextInt();

			// Calculate the sum of elements in the range of L and R
			int sum = 0;
			for (int i = L; i <= R; i++) {
			    sum += array[i];
			}

			System.out.println("Sum of elements in the range of L and R: " + sum);
		}
    }
}
