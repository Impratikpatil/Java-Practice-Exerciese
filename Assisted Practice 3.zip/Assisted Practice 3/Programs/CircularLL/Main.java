package CircularLL;

class Node {
    int data;
    Node next;
 
    public Node(int data) {
        this.data = data;
        this.next = null;
    }
}
 
class CircularLinkedList {
    Node head;
 
    // Function to insert a new element in a sorted circular linked list
    
    void insert(int data) {
        Node newNode = new Node(data);
 
        // If the list is empty, make the new node as the head and point its next to itself
       
        if (head == null) {
            head = newNode;
            newNode.next = head;
        }
        
        // If the new node's data is less than the head's data, insert it at the beginning
       
        else if (data < head.data) {
            newNode.next = head;
            Node current = head;
            while (current.next != head) {
                current = current.next;
            }
            current.next = newNode;
            head = newNode;
        }
        
        // If the new node's data is greater than the head's data, find its correct position and insert it
       
        else {
            Node current = head;
            while (current.next != head && current.next.data < data) {
                current = current.next;
            }
            newNode.next = current.next;
            current.next = newNode;
        }
    }
 
    
    // Function to print the circular linked list
  
    void display() {
        if (head == null) {
            System.out.println("List is empty");
            return;
        }
        Node current = head;
        do {
            System.out.print(current.data + " ");
            current = current.next;
        } while (current != head);
    }
}
 
public class Main {
    public static void main(String[] args) {
        CircularLinkedList list = new CircularLinkedList();
 
        // Insert elements in a sorted manner
        list.insert(10);
        list.insert(20);
        list.insert(30);
        list.insert(40);
        list.insert(50);
 
        System.out.println("Circular Linked List after insertion:");
        list.display();
    }
}

