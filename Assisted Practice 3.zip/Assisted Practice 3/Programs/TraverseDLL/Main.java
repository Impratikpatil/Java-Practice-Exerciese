package TraverseDLL;

class Node {
    int data;
    Node prev;
    Node next;

    Node(int data) {
        this.data = data;
        this.prev = null;
        this.next = null;
    }
}

class DoublyLinkedList {
    Node head;

    DoublyLinkedList() {
        this.head = null;
    }

    // Add a node to the end of the list
    
    public void add(int data) {
        Node newNode = new Node(data);
        if (head == null) {
            head = newNode;
        } else {
            Node current = head;
            while (current.next != null) {
                current = current.next;
            }
            current.next = newNode;
            newNode.prev = current;
        }
    }

    // Traverse the list in forward direction
    
    public void traverseForward() {
        if (head == null) {
            System.out.println("List is empty is:");
        } else {
            Node current = head;
            System.out.print("List in forward direction is:\n ");
            while (current != null) {
                System.out.print(current.data + " ");
                current = current.next;
            }
            System.out.println();
        }
    }

    // Traverse the list in backward direction
    
    public void traverseBackward() {
        if (head == null) {
            System.out.println("List is empty is:");
        } else {
            Node current = head;
            while (current.next != null) {
                current = current.next;
            }
            System.out.print("\nList in backward direction is:\n ");
            while (current != null) {
                System.out.print(current.data + " ");
                current = current.prev;
            }
            System.out.println();
        }
    }
}

public class Main {
    public static void main(String[] args) {
        DoublyLinkedList list = new DoublyLinkedList();
        list.add(50);
        list.add(60);
        list.add(70);
        list.add(80);
        list.add(90);
        list.traverseForward();
        list.traverseBackward();
    }
}
