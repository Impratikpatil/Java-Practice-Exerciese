package Queue;

import java.util.LinkedList;
import java.util.Queue;

public class Main {
    public static void main(String[] args) {
    	
        // Create a queue
        Queue<Integer> queue = new LinkedList<>();

        // Insert elements into the queue
        queue.add(10);
        queue.add(20);
        queue.add(30);
        
        System.out.println("Queue after add operation: " + queue);

        
        // Remove the element at the front of the queue
        
        int removedElement = queue.remove();
        System.out.println("Removed element: " + removedElement);
        System.out.println("\nQueue after remove operation: " + queue);

        // Retrieve the element at the front of the queue without removing it
        
        int frontElement = queue.peek();
        System.out.println("Front element: " + frontElement);
        System.out.println("\nQueue after peek operation: " + queue);

        // Check if the queue contains a specific element
       
        int searchElement = 20;
        boolean containsElement = queue.contains(searchElement);
        System.out.println("\nQueue contains " + searchElement + ": " + containsElement);
    }
}

