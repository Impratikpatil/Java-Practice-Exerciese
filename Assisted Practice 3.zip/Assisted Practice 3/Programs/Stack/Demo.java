package Stack;
import java.util.Stack;

public class Demo {
    public static void main(String[] args) {
    	
        // Create a stack
        Stack<Integer> stack = new Stack<>();

        // Insert elements into the stack
        stack.push(10);
        stack.push(20);
        stack.push(30);
        stack.push(40);
        stack.push(50);
        
        System.out.println("Stack after push operation: " + stack);

        // Remove the top element from the stack
        
        int poppedElement = stack.pop();
        System.out.println("Popped element: " + poppedElement);
        System.out.println("\nStack after pop operation: " + stack);

        // Peek at the top element of the stack without removing it
      
        int topElement = stack.peek();
        System.out.println("Top element: " + topElement);
        System.out.println("\nStack after peek operation: " + stack);

        // Search for an element in the stack
       
        int searchElement = 40;
        int position = stack.search(searchElement);
        System.out.println("Position of " + searchElement + " in stack: " + position);
    }
}

