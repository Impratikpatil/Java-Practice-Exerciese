package SinglyLL;

public class LinkedList {
    Node head;
    
    class Node {
        int data;
        Node next;
        
        Node(int data) {
            this.data = data;
            this.next = null;
        }
    }
    
    public void deleteFirstOccurrence(int key) {
        Node current = head;
        Node prev = null;
        
        while (current != null && current.data != key) {
            prev = current;
            current = current.next;
        }
        
        if (current == null) {
            return;
        }
        
        if (prev == null) {
            head = current.next;
        } else {
            prev.next = current.next;
        }
    }
    
    public void insert(int data) {
        Node newNode = new Node(data);
        
        if (head == null) {
            head = newNode;
            return;
        }
        
        Node current = head;
        while (current.next != null) {
            current = current.next;
        }
        
        current.next = newNode;
    }
    
    public void printList() {
        Node current = head;
        while (current != null) {
            System.out.print(current.data + " ");
            current = current.next;
        }
        System.out.println();
    }
    
    public static void main(String[] args) {
        LinkedList list = new LinkedList();
        list.insert(1);
        list.insert(2);
        list.insert(3);
        list.insert(4);
        list.insert(5);
        
        System.out.println("Original list is:");
        list.printList();
        
        list.deleteFirstOccurrence(3);
        System.out.println("List after deleting first occurrence of 3 is:");
        list.printList();
    }
}
