package RightRotate;

public class RightRotateArray {
	
    public static void main(String[] args) {
    	
        int[] arr = {1, 2, 3, 4, 5, 6, 7, 8, 9,10};
        int n = arr.length;
        int k = 5;
        System.out.println("The Original Array is:");
        for (int i = 0; i < n; i++) {
            System.out.print(arr[i] + " ");
        }
        
        System.out.println();
        rightRotate(arr, n, k);
        System.out.println("Array after " + k + " right rotations will be:");
        for (int i = 0; i < n; i++) {
            System.out.print(arr[i] + " ");
        }
    }
    
    public static void rightRotate(int[] arr, int n, int k) {
    	
        // rotate k times
        for (int i = 0; i < k; i++) {
        	
            // store the last element
            int temp = arr[n - 1];
            
            // shift the elements to the right
            for (int j = n - 1; j > 0; j--) {
                arr[j] = arr[j - 1];
            }
            
            // put the last element at the beginning
            arr[0] = temp;
        }
    }
}

