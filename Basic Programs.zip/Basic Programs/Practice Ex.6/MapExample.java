package Map;

import java.util.HashMap;
import java.util.Map;

public class MapExample {
    public static void main(String[] args) {
    	
        // Create a HashMap
    	
        Map<String, Integer> map = new HashMap();
        
        // Add some entries to the map
        
        map.put("Akash", 25);
        map.put("Bhagat", 30);
        map.put("Chand", 35);
        
        // Get the value associated with a key
        
        int age = map.get("Bhagat");
        System.out.println("Bhagat's age is: " + age);
        
        // Check if a key exists in the map
        
        boolean exists = map.containsKey("Chand");
        System.out.println("Chand's exists is: " + exists);
        
        // Iterate over the entries in the map
        
        for (Map.Entry<String, Integer> entry : map.entrySet()) {
            String name = entry.getKey();
            int value = entry.getValue();
            System.out.println(name + " is " + value + " years old");
        }
    }
}
