package String;

public class StringConversion {

	public static void main(String[] args)
	{
		        String str = "Hey Siri!";
		        
		        // Convert to StringBuffer
		        
		        StringBuffer stringBuffer = new StringBuffer(str);
		        System.out.println("StringBuffer: " + stringBuffer);
		        
		        // Convert to StringBuilder
		        
		        StringBuilder stringBuilder = new StringBuilder(str);
		        System.out.println("StringBuilder: " + stringBuilder);
		    }
		
	}


