package Collection;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class CollectionVerificationEx {

    public static void main(String[] args) {
    	
        // Verify implementation of List
    	
        List<String> list = new ArrayList();
        list.add("Apple");
        list.add("Banana");
        list.add("Mango");
        if (list.size() == 3 && list.contains("Mango")) {
            System.out.println("List implementation is correct.");
        } 
        else {
            System.out.println("List implementation is incorrect.");
        }

        // Verify implementation of Map
        
        Map<String, Integer> map = new HashMap();
        map.put("Apple", 1);
        map.put("Strawberry", 2);
        map.put("Coconut", 3);
        if (map.size() == 3 && map.containsKey("Strawberry")) {
            System.out.println("Map implementation is correct.");
        } 
        else {
            System.out.println("Map implementation is incorrect.");
        }
    }
}
