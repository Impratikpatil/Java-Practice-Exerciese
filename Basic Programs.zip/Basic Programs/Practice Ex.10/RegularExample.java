package RegularExp;

import java.util.regex.*;

public class RegularExample 
{
    public static void main(String[] args) 
    {
        String input = "The quick brown cat jumps over the lazy dog";
        String regex = "quick.*cat";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(input);
        
        if (matcher.find()) 
        {
            System.out.println("Match found!");
            System.out.println("Matched string: " + matcher.group());
        } 
        else {
            System.out.println("Match not found.");
        }
    }
}