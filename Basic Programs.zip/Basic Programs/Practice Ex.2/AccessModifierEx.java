package AccessModifier;

public class AccessModifierEx {
	
    // Public access modifier
    public String publicVariable = "Public variable";

    // Private access modifier
    private String privateVariable = "Private variable";

    // Default access modifier
    String defaultVariable = "Default variable";

    // Protected access modifier
    protected String protectedVariable = "Protected variable";

    // Public method
    public void publicMethod() {
        System.out.println("Public method");
    }

    // Private method
    private void privateMethod() {
        System.out.println("Private method");
    }

    // Default method
    void defaultMethod() {
        System.out.println("Default method");
    }

    // Protected method
    protected void protectedMethod() {
        System.out.println("Protected method");
    }

    public static void main(String[] args) {
        AccessModifierEx obj = new AccessModifierEx();

        // Accessing variables
        System.out.println(obj.publicVariable);
        System.out.println(obj.privateVariable);
        System.out.println(obj.defaultVariable);
        System.out.println(obj.protectedVariable);

        // Accessing methods
        obj.publicMethod();
        obj.privateMethod();
        obj.defaultMethod();
        obj.protectedMethod();
    }
}
