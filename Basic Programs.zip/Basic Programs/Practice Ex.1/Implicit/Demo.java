package Implicit;

public class Demo {

	public static void main(String[] args) {
		int num=10;
		System.out.println("int value:" + num);
        float data = num;
        System.out.println("The Float Value:" + data);
	}

}
