package Explicit;

public class Main {

	public static void main(String[] args) {
		double num=10.22;
		System.out.println("double value:" + num);
        int data = (int)num;
        System.out.println("The Int Value:" + data);
	}

}