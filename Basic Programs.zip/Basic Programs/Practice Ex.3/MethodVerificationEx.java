package CallingMethod;

public class MethodVerificationEx {

    public static int sum(int a, int b) {
        return a + b;
    }

    public static void main(String[] args) {
    	
        // Verify implementation of sum() method
    	
        int result = sum(11, 19);
        if (result == 30) {
            System.out.println("sum() method implementation is correct.");
        } 
        else {
            System.out.println("sum() method implementation is incorrect.");
        }

        // Verify way of calling sum() method
        
        int x = 25;
        int y = 25;
        result = sum(x, y);
        if (result == 50) {
            System.out.println("Way of calling sum() method is correct.");
        } 
        else {
            System.out.println("Way of calling sum() method is incorrect.");
        }
    }
}
