package Classes;

public class OuterClass {
    private int outerData = 10;
    
    // Inner class definition
    
    public class InnerClass {
        private int innerData = 20;
        
        public void printOuterData() {
            System.out.println("Outer data: " + outerData);
        }
        
        public void printInnerData() {
            System.out.println("Inner data: " + innerData);
        }
    }
    
    public static void main(String[] args) {
    	
        // Create an instance of the outer class
    	
        OuterClass outer = new OuterClass();
        
        // Create an instance of the inner class
        
        InnerClass inner = outer.new InnerClass();
        
        // Call methods of the inner class
        
        inner.printOuterData();
        inner.printInnerData();
    }
}
