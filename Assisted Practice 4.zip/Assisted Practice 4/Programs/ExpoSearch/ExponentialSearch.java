package ExpoSearch;

public class ExponentialSearch {
	
    public static int exponentialSearch(int[] array, int target) {
        if (array[0] == target) {
            return 0;  // Found the target at index 0
        }
        
        int i = 1;
        while (i < array.length && array[i] <= target) {
            i *= 2;  // Double the value of i
        }
        
        return binarySearch(array, target, i / 2, Math.min(i, array.length - 1));
    }
    
    public static int binarySearch(int[] array, int target, int left, int right) {
        while (left <= right) {
            int mid = left + (right - left) / 2;
            
            if (array[mid] == target) {
                return mid;  // Found the target at index mid
            } else if (array[mid] < target) {
                left = mid + 1;  // Search in right half
            } else {
                right = mid - 1;  // Search in left half
            }
        }
        
        return -1;  // Target not found in array
    }

    public static void main(String[] args) {
        int[] numbers = {10,20,30,40,50,};
        int target = 10;
        int index = exponentialSearch(numbers, target);
        
        if (index != -1) {
            System.out.println("Target found at index : " + index);
        } else {
            System.out.println("Target not found in the array");
        }
    }
}
