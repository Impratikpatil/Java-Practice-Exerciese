package LinearSearch;

public class LinearSearchDemo {
    public static int linearSearch(int[] array, int target) {
        for (int i = 0; i < array.length; i++) {
            if (array[i] == target) {
                return i; // Found the target, return its index
            }
        }
        
        return -1; // Target not found
    }

    public static void main(String[] args) {
        int[] array = { 5, 3, 8, 2, 9, 1 };
        int target = 1;
        
        int result = linearSearch(array, target);
        
        if (result == -1) {
        	
            System.out.println("Target not found in the array.");
        } 
          else {
        	  
            System.out.println("Target found at index: " + result);
        }
    }
}
