package Merge_Sort;

public class MergeSortDemo {
	
    public static void mergeSort(int[] array) {
        if (array.length <= 1) {
            return; // Base case: array is already sorted
        }
        
        int mid = array.length / 2;
        int[] left = new int[mid];
        int[] right = new int[array.length - mid];
        
        // Split the array into two halves
        for (int i = 0; i < mid; i++) {
            left[i] = array[i];
        }
        for (int i = mid; i < array.length; i++) {
            right[i - mid] = array[i];
        }
        
        mergeSort(left); 
        mergeSort(right); 
        
        merge(left, right, array); 
    }
    
    public static void merge(int[] left, int[] right, int[] merged) {
        int i = 0; 
        int j = 0; 
        int k = 0; 
        
        while (i < left.length && j < right.length) {
            if (left[i] <= right[j]) {
                merged[k] = left[i];
                i++;
            } else {
                merged[k] = right[j];
                j++;
            }
            k++;
        }
        
        // Copy the remaining elements from the left array, if any
        while (i < left.length) {
            merged[k] = left[i];
            i++;
            k++;
        }
        
        // Copy the remaining elements from the right array, if any
        while (j < right.length) {
            merged[k] = right[j];
            j++;
            k++;
        }
    }

    public static void main(String[] args) {
        int[] numbers = {15,55,35,25,45};
        
        System.out.println("Array before sorting:");
        printArray(numbers);
        
        mergeSort(numbers);
        
        System.out.println("\nArray after sorting:");
        printArray(numbers);
    }
    
    public static void printArray(int[] array) {
        for (int num : array) {
            System.out.print(num + " ");
        }
        System.out.println();
    }
}

