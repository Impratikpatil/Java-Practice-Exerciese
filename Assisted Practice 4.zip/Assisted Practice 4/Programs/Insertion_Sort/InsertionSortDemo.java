package Insertion_Sort;

public class InsertionSortDemo {
	
    public static void insertionSort(int[] array) {
        int n = array.length;
        
        for (int i = 1; i < n; i++) {
            int key = array[i];
            int j = i - 1;
            
            while (j >= 0 && array[j] > key) {
                array[j + 1] = array[j];
                j--;
            }
            
            array[j + 1] = key;
        }
    }

    public static void main(String[] args) {
        int[] numbers = {9,6,3,8,5,2};
        
        System.out.println("Array before sorting:");
        printArray(numbers);
        
        insertionSort(numbers);
        
        System.out.println("\nArray after sorting:");
        printArray(numbers);
    }
    
    public static void printArray(int[] array) {
        for (int num : array) {
            System.out.print(num + " ");
        }
        System.out.println();
    }
}

