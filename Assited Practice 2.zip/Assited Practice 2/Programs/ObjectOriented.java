package Pillars_In_Java;

//Example class representing a Bank Account
class BankAccount {
 private String accountNumber;
 private String accountHolder;
 private double availablebalance;

 // Constructor
 public BankAccount(String accountNumber, String accountHolder) {
     this.accountNumber = accountNumber;
     this.accountHolder = accountHolder;
     this.availablebalance = 0.0;
 }

 // Getter methods
 public String getAccountNumber() {
     return accountNumber;
 }

 public String getAccountHolder() {
     return accountHolder;
 }

 public double getBalance() {
     return availablebalance;
 }

 // Method to deposit money
 public void deposit(double amount) {
     if (amount > 0) {
    	 availablebalance += amount;
         System.out.println("Deposit : $" + amount + " Successful.");
     } else {
         System.out.println("Invalid Deposit Amount.");
     }
 }

 // Method to withdraw money
 public void withdraw(double amount) {
     if (amount > 0 && amount <= availablebalance) {
    	 availablebalance = amount;
         System.out.println("Withdrawal : $" + amount + " Successful.");
     } else {
         System.out.println("Invalid Withdrawal Wmount or Insufficient Balance.");
     }
 }
}

public class ObjectOriented {
 public static void main(String[] args) {
	 
     // Create objects of BankAccount class
	 
     BankAccount account = new BankAccount("123456789", "Akash Ambani");
     

     // Accessing object properties and invoking methods
     System.out.println("Account Holder: " + account.getAccountHolder() + " - AvailableBal: $" + account.getBalance());
    

     account.deposit(1000.0);
     
     System.out.println("Account Holder: " + account.getAccountHolder() + " - AvailableBal: $" + account.getBalance());
    

     account.withdraw(500.0);
     
     System.out.println("Account Holder: " + account.getAccountHolder() + " - AvailableBal: $" + account.getBalance());
     
 }
}
