package RunnableInterface;

//Thread creation by extending the Thread class
class MyThread extends Thread {
@Override
public void run() {
   for (int i = 1; i <= 5; i++) {
       System.out.println("Thread 1: " + i);
   }
}
}

//Thread creation by implementing the Runnable interface
class MyRunnable implements Runnable {
	
@Override
public void run() {
   for (int i = 1; i <= 5; i++) {
       System.out.println("Thread 2: " + i);
   }
}
}

public class ThreadExample {
public static void main(String[] args) {
	
   // Creating a thread by extending the Thread class
   MyThread thread1 = new MyThread();
   thread1.start(); // Start the thread

   // Creating a thread by implementing the Runnable interface
   MyRunnable myRunnable = new MyRunnable();
   Thread thread2 = new Thread(myRunnable);
   thread2.start(); // Start the thread
}
}

