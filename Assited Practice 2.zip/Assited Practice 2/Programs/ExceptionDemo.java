package Exception;

public class ExceptionDemo {
    public static void main(String[] args) {
        try {
            divideNumbers(10, 0); // Call a method that throws an exception
        } catch (CustomException e) {
            System.out.println("CustomException caught: " + e.getMessage());
        } finally {
            System.out.println("Finally block executed.");
        }
    }

    public static void divideNumbers(int dividend, int divisor) throws CustomException {
        try {
            if (divisor == 0) {
                throw new CustomException("Divisor cannot be zero.");
            }
            int result = dividend / divisor;
            System.out.println("Result: " + result);
        } finally {
            System.out.println("Finally block inside divide Numbers method executed.");
        }
    }
}

@SuppressWarnings("serial")
class CustomException extends Exception {
    public CustomException(String message) {
        super(message);
    }
}

