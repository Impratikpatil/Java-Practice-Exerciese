package OOPsconcepts;

public class Diamond_Problem {
    public static void main(String[] args) 
    {
        D obj = new D();
        obj.print();
    }
}

interface A {
    default void print() 
    {
        System.out.println("A");
    }
}

interface B extends A {
    default void print() 
    {
        System.out.println("B");
    }
}

interface C extends A {
    default void print() 
    {
        System.out.println("C");
    }
}

class D implements B, C {
    public void print() 
    {
        B.super.print(); // Explicitly call B print() method
        C.super.print(); // Explicitly call C print() method
    }
}


